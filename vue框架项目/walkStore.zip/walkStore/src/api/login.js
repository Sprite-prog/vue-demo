
export default {
  //登录
  'LOGIN_API': '/uaa/auth/form',
  //验证码
  'VALIDATE_CODE_API': '/uaa/auth/code/image',
  //菜单树
  'MENUS_API': '/webauth/menu/listUserMenus'
}