export default {
  //热门位商品管理 查询 by zheng_r 20190514
  //'LOGIN_API': '/uaa/auth/form',
  'HOT_GOOD_QUERY': '/pc/hotGoods/listHotGoods',
  // 热门位商品管理 删除 by zheng_r 20190514
  'HOT_GOOD_API_DEL': '/pc/hotGoods/deleteHotGoods',
  // 展示数量设置
  'HOT_SET_SHOW_NUM': '/pc/hotGoods/setShowNum',
  // 新增
  'HOT_GOODS_ADD': '/pc/hotGoods/addHotGoods',
  // 修改
  'HOT_GOOD_UPDATE': '/pc/hotGoods/updateHotGoods',
  // 商品查询
  'GOOD_SKU_QUERY': '/pc/tGoodsSku/getPageTGoodsSku',
  // 原商品数量展示
  'SHOW_NUM_QUERY': '/pc/hotGoods/queryShowNum',
}
