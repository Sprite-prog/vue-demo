export default {
  //家长端信息管理 查询 by zheng_r 20190515
  'PATRIARCH_QUERY_API': '/pc/patriarch/listPatriarchInfo',
  //家长端信息管理 删除 by zheng_r 20190515
  'PATRIARCH_REMOVE_API': '/pc/patriarch/removePatriarchInfo',
  /**修改密码 */
  'PATRIARCH_UPDATE_PWD_API': '/webauth/user/updatePwd',
}
