export default {
  //日志 查询 by zheng_r 20190521
  'LOG_QUERY_API': '/pc/log/listLog',
}
