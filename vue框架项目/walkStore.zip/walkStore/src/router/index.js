import Vue from 'vue';
import Router from 'vue-router';

Vue.use(Router);

/* 路由模块集合 */
//系统管理
import systemRouter from './modules/systemManage'


//登录页
const login = r => require.ensure([], () => r(require('@/pages/login.vue')), 'login');
//主页面
const index = r => require.ensure([], () => r(require('@/components/home.vue')), 'index');
//系统首页
const dashboard = r => require.ensure([], () => r(require('@/pages/dashboard.vue')), 'dashboard');
//403
const forbid = r => require.ensure([], () => r(require('@/pages/403.vue')), '403');
//404
const error = r => require.ensure([], () => r(require('@/pages/404.vue')), '404');

export default new Router({
  routes: [{
      path: '/',
      redirect: '/login',
    },
    {
      path: '/',
      component: index,
      children: [{
          path: '/dashboard',
          name: 'Dashboard',
          component: dashboard,
          meta: {
            keepAlive: true,
            title: '首页'
          }
        },
        {
          path: '/404',
          component: error,
          meta: {
            title: '404'
          }
        },
        {
          path: '/403',
          component: forbid,
          meta: {
            title: '403'
          }
        },
      ]
    },
    systemRouter,
    {
      path: '/login',
      component: login
    },
    {
      path: '*',
      redirect: '/404'
    }
  ]
})
