//prodUrl: 正式环境的地址
let prodUrl = 'http://192.168.1.61:8083';

export {
	prodUrl
}