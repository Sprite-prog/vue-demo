//devUrl:测试环境的地址
//let devUrl = "http://2i33960u09.iok.la";
let devUrl = 'http://10.100.12.21:8080';
//let devUrl = 'http://e3ab720.ittun.com'
//let devUrl = 'http://1o60519j63.imwork.net:59960'
//let devUrl = 'http://2y505j6699.zicp.vip:11117'
//let devUrl = 'http://10.100.12.20:8080';
export {
  devUrl
};
